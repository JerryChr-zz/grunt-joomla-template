Ready for some Grunt magic?

Steps:
1. Install Nodejs - https://nodejs.org/
2. Open CMD/Terminal - and change directory to the grunt folder "grunt-template/grunt"
3. Enter "npm install" - it will now install all the npm modules, depending on your internet connection this can take up to 5 minutes to download everything.
4. Write "grunt"

If you need more introduction:
A really good introduction to Grunt was written by Chris Coyier back in 2013 http://24ways.org/2013/grunt-is-not-weird-and-hard/
